package com.example.demo.security.enums;

public enum RollNombre {
    ROLE_ADMIN, ROLE_USER
    
}
