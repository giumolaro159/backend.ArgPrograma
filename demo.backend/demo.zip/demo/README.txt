Este proyecto está licenciado bajo la Apache License 2.0. Ver el archivo LICENSE.txt para más detalles.
